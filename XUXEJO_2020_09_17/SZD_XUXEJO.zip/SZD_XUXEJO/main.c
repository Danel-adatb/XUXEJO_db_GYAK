#include <stdio.h>
#include <stdlib.h>

int main()
{
    //writeFile();
    copyFile();
    return 0;
}

//2. feladat
void writeFile() {
    FILE *fp;
    char ch;
    char fname[50];
    printf("Filename: ");
    scanf("%s",fname);
    fp = fopen(fname,"w");
    printf("Message: ");

    while((ch = getchar()) != '#') {
        putc(ch,fp);
    }
    fclose(fp);

    fp = fopen(fname, "r");

    while((ch = getc(fp)) != EOF) {
        printf("%c", ch);
    }

    fclose(fp);

    return 0;
}

//3. feladat
void copyFile() {
    FILE *fptr1, *fptr2;
    char filename[100], c;

    printf("Enter the filename to open for reading \n");
    scanf("%s", filename);

    fptr1 = fopen(filename, "r");

    printf("Enter the filename to open for writing \n");
    scanf("%s", filename);

    fptr2 = fopen(filename, "w");

    c = fgetc(fptr1);
    while (c != EOF)
    {
        fputc(c, fptr2);
        c = fgetc(fptr1);
    }

    printf("\nContents copied to %s", filename);

    fclose(fptr1);
    fclose(fptr2);
    return 0;
}
